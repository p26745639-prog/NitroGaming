NITRO GAMING - Proyecto Android Studio

Incluye:
- Pantalla inicial con enlace al canal OFFHACK.
- Detección automática de fabricante, modelo y versión de Android.
- Panel Modo Gaming y accesos a ajustes compatibles.
- Guía para activar Opciones de desarrollador.
- Botón de restablecimiento de preferencias internas de la app.

IMPORTANTE:
Android no ofrece enlaces universales para velocidad del puntero ni DPI/ancho mínimo. Los accesos abren ajustes generales, accesibilidad u Opciones de desarrollador y muestran instrucciones. La app no modifica de forma silenciosa ajustes protegidos del sistema ni puede garantizar aumento de FPS.
El botón Restablecer borra preferencias internas de NITRO GAMING; no revierte por sí solo cambios hechos manualmente en Ajustes de Android. Anota los valores originales antes de cambiarlos.

Para generar el APK:
1. Instala Android Studio.
2. Abre esta carpeta como proyecto (File > Open).
3. Acepta la sincronización de Gradle e instala Android SDK 35 si se solicita.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración aparecerá en app/build/outputs/apk/debug/app-debug.apk.

Paquete: com.offhack.nitrogaming
Versión: 1.0
