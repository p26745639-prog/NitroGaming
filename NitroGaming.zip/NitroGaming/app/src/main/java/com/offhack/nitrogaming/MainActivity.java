package com.offhack.nitrogaming;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String YOUTUBE = "https://youtube.com/@offhackhack?si=pVtcVNBp8pgNEryq";
    private static final int BG = Color.rgb(5, 10, 20), PANEL = Color.rgb(13, 25, 43), CYAN = Color.rgb(32, 215, 255), GREEN = Color.rgb(64, 245, 158), WHITE = Color.WHITE, MUTED = Color.rgb(170, 190, 215);
    private LinearLayout root;
    private SharedPreferences prefs;
    private boolean entered = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("nitro", MODE_PRIVATE);
        showWelcome();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER); t.setPadding(8, 8, 8, 8); return t;
    }
    private LinearLayout page() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20, 24, 20, 28); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll); return root;
    }
    private void heading(String subtitle) {
        root.addView(text("⚡ NITRO GAMING ⚡", 28, CYAN, true));
        root.addView(text(subtitle, 14, MUTED, false));
        root.addView(text("━━━━━━━━━━━━━━━━━━━━", 13, GREEN, true));
    }
    private void showWelcome() {
        page(); heading("TU RENDIMIENTO · TU JUEGO · TU POTENCIA");
        root.addView(text("🎮", 66, GREEN, true));
        root.addView(text("¡BIENVENIDO, GAMER!", 24, WHITE, true));
        root.addView(text("Apoya el canal OFFHACK en YouTube y descubre las herramientas de NITRO GAMING.", 16, MUTED, false));
        addButton("▶  SUSCRIBIRME A OFFHACK", true, v -> openUrl(YOUTUBE));
        addButton("CONTINUAR A NITRO GAMING", false, v -> showHome());
        root.addView(text("La suscripción es voluntaria. NITRO GAMING no puede verificar si te suscribiste.", 12, MUTED, false));
    }
    private void showHome() {
        entered = true; page(); heading("PANEL DE CONTROL GAMING");
        String device = Build.MANUFACTURER + " " + Build.MODEL;
        root.addView(text("DISPOSITIVO DETECTADO", 13, GREEN, true));
        root.addView(text(device, 19, WHITE, true));
        root.addView(text("Android " + Build.VERSION.RELEASE + " · Puedes cambiar la marca de referencia en el selector.", 12, MUTED, false));
        addButton("🎮  MODO GAMING · VER HERRAMIENTAS", true, v -> showGaming());
        addButton("🖱  VELOCIDAD DEL PUNTERO", false, v -> openSettings(Settings.ACTION_SETTINGS, "Busca Sistema, Idiomas/entrada o Teclado y ratón. Android no ofrece un enlace universal al control de velocidad."));
        addButton("✨  ESCALAS DE ANIMACIÓN", false, v -> openDeveloper("En Opciones de desarrollador, busca Escala de animación de ventana, transición y duración de Animator. Puedes elegir 0.5x o 1x."));
        addButton("👆  CLIC AUTOMÁTICO · TIEMPO DE PERMANENCIA", false, v -> openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS, "En Accesibilidad busca Tiempo de permanencia / Clic automático. El nombre y la disponibilidad dependen del fabricante."));
        addButton("📐  DPI · ANCHO MÍNIMO", false, v -> openDeveloper("En Opciones de desarrollador busca Ancho mínimo. Anota el valor original antes de cambiarlo; un valor incorrecto puede hacer difícil usar la pantalla."));
        addButton("📘  GUÍA PARA ACTIVAR OPCIONES DE DESARROLLADOR", false, v -> showDeveloperGuide());
        addButton("↩  RESTABLECER PARÁMETROS DE NITRO", false, v -> confirmReset());
        root.addView(text("NITRO GAMING solo abre ajustes del sistema y guarda tus preferencias dentro de la app. No cambia ajustes protegidos automáticamente ni promete aumentar FPS.", 12, MUTED, false));
        addButton("YouTube · OFFHACK", false, v -> openUrl(YOUTUBE));
    }
    private void showGaming() {
        page(); heading("MODO GAMING");
        root.addView(text("Elige una herramienta. Los accesos disponibles varían según la versión de Android y la marca.", 14, MUTED, false));
        addButton("VELOCIDAD DEL PUNTERO", true, v -> openSettings(Settings.ACTION_SETTINGS, "Busca los ajustes de ratón o entrada. Algunos teléfonos no muestran esta opción."));
        addButton("ESCALAS DE ANIMACIÓN", false, v -> openDeveloper("Ajusta las tres escalas de animación desde Opciones de desarrollador."));
        addButton("TIEMPO DE PERMANENCIA", false, v -> openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS, "Busca Tiempo de permanencia o Clic automático."));
        addButton("DPI / ANCHO MÍNIMO", false, v -> openDeveloper("Busca Ancho mínimo. Registra el valor actual antes de modificarlo."));
        addButton("← VOLVER AL INICIO", false, v -> showHome());
    }
    private void showDeveloperGuide() {
        new AlertDialog.Builder(this).setTitle("Activar opciones de desarrollador")
          .setMessage("1. Abre Ajustes del teléfono.\n2. Entra en Acerca del teléfono.\n3. Busca Versión de MIUI / Versión de HyperOS o Número de compilación.\n4. Toca esa opción 7 veces hasta ver el aviso de que eres desarrollador. Puede pedir tu PIN.\n5. Vuelve a Ajustes > Ajustes adicionales (en Xiaomi/Redmi) > Opciones de desarrollador.\n\nLos nombres pueden variar según el modelo y la versión. No compartas tu PIN.")
          .setPositiveButton("Abrir ajustes", (d,w) -> openSettings(Settings.ACTION_SETTINGS, "Busca Acerca del teléfono para activar las opciones de desarrollador."))
          .setNegativeButton("Cerrar", null).show();
    }
    private void openDeveloper(String help) {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
        new AlertDialog.Builder(this).setTitle("Qué debes buscar").setMessage(help).setPositiveButton("Entendido", null).show();
    }
    private void openSettings(String action, String help) {
        try { startActivity(new Intent(action)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        new AlertDialog.Builder(this).setTitle("Siguiente paso").setMessage(help).setPositiveButton("Entendido", null).show();
    }
    private void confirmReset() {
        new AlertDialog.Builder(this).setTitle("Restablecer NITRO GAMING")
          .setMessage("NITRO GAMING no modifica automáticamente la velocidad del puntero, DPI ni escalas del sistema. Este botón borrará las preferencias guardadas dentro de la aplicación. Para revertir cambios del sistema, vuelve a cada ajuste y restaura el valor que anotaste.")
          .setNegativeButton("Cancelar", null).setPositiveButton("Restablecer app", (d,w) -> {
              prefs.edit().clear().apply(); Toast.makeText(this, "Preferencias de NITRO restablecidas", Toast.LENGTH_LONG).show(); showHome();
          }).show();
    }
    private void addButton(String label, boolean primary, View.OnClickListener click) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary ? Color.rgb(0, 115, 160) : PANEL));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 8, 0, 8); root.addView(b, lp); b.setOnClickListener(click);
    }
    private void openUrl(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { Toast.makeText(this, "No se pudo abrir YouTube", Toast.LENGTH_SHORT).show(); } }
}
